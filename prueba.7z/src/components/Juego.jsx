import React from "react";

const Juego = () => {
    return (<h1>EcoWordle</h1>)
}

export default Juego
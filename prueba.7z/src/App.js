import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Juego from './components/Juego';
import Home from './components/home';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
        <BrowserRouter>
      <Routes>
        <Route path='/' element={<Layout />}>
          <Route index element={<Home />}></Route>
          <Route path='/Juego' element={<Juego />} ></Route>
          <Route path='*' element={<h1>Not Found</h1>} ></Route>
        </Route>
      </Routes>
    </BrowserRouter>
        </p>
      </header>
    </div>
    
  );
}

export default App;
